/** Automatically generated file. DO NOT MODIFY */
package com.desarrollodroide.fragmenttrasitionextendedexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}