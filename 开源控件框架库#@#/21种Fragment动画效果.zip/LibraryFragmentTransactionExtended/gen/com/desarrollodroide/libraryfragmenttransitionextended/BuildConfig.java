/** Automatically generated file. DO NOT MODIFY */
package com.desarrollodroide.libraryfragmenttransitionextended;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}